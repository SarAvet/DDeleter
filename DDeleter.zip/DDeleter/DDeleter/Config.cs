﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace DDeleter
{
    class Config
    {
        //Функции
        //5. Изменение файла конфигурации

        //Свойства
        //1. Путь к файлу конфигурации
        //2. Свойства программы
        //3. Исключаемые файлы

        /* Путь к конфигурационному файлу
         * 
         */
        private string _path;

        /* Режим вывода результата
         * 0 - вывод по первому попавшемуся
         * 1 - отсортированный результат
         */
        private short _modDataOut;

        /* Исключаемые типы файлов 
         * 
         */
        private String[] _exceptionTypes;

        /* Имя файла конфигурации
         * 
         */
        private string _fileName;

        /* Конструктор.
         * Установка параметров по умолчанию
         * 
         */
        Config()
        {
            this._path = Directory.GetCurrentDirectory();
            this._modDataOut = 0;
            this._exceptionTypes = new String[0];
            this._fileName = "config";
        }

        public void createConfigFile()
        {
            string fulFilePath = this._path + "\\" + this._fileName;

            string configText = "[Путь = "+fulFilePath+"]\r\n"+
            "[Режим вывода = "+convertOutMode(this._modDataOut)+"]\r\n"+
            "[Исключаемые типы данных = "+this._exceptionTypes+"]";

            if (!File.Exists(fulFilePath))
                File.Create(fulFilePath);
            
            
        }

        private string convertOutMode(short mode)
        {
            switch(mode)
            {
                case 0:
                    return "вывод отсортированного результата";
                case 1:
                    return "хаотичный вывод";
                default:
                    return "Ошибка."; 
            }
            
        }

    }
}

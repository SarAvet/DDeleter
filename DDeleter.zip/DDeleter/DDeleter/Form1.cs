﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Drawing;

namespace DDeleter
{
    public partial class Form1 : Form
    {
        delegate void SetPBMaxValue();
        int countOfFile;
        string[] filesInDirectory, dirInDirectory;
        string doubleFileName;
        List<string> needFiles;
        List<string> allFiles;
        public Form1()
        {
            InitializeComponent();
            needFiles = new List<string>();
            allFiles = new List<string>();
            path.TextChanged += doubleName_TextChanged;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (FolderDialog.ShowDialog() == DialogResult.OK)
                path.Text = FolderDialog.SelectedPath;

        }

        private void button1_Click(object sender, EventArgs e)
        {

            //Имя файла предполагаемого дубля
            doubleFileName = doubleName.Text;
            //Путь к корневой папке
            string filePath = path.Text;
            //Установка панели в нерабочее состояние для предотвращения повторных нажатий
            panel1.Enabled = false;
            //Удаление ранее найденных дублей 
            if (checkedListBox1.Items.Count != 0)
                checkedListBox1.Items.Clear();

            /* Рассматриваются два случая:
             * 1. Рассмотреть все папки
             * 2. Рассмотреть конкретную папку и вложенные в нее папки 
             */

            //1-ый случай
            if (filePath.Equals("*"))
            {
                //Инициализация пустого массива с файлами, что означает отстуствие файлов в данной папке
                filesInDirectory = new string[0];
                //Получение активных логических дисков
                getDrives();
            }
            else
            {
                //2-ой случай
                try
                {
                    //Получение файлов из данной директории
                    filesInDirectory = Directory.GetFiles(filePath);
                    //Получение папок из данной директории
                    dirInDirectory = Directory.GetDirectories(filePath);
                }
                catch (UnauthorizedAccessException exp)
                {
                    MessageBox.Show(exp.Message);
                }

            }


            //Запуск фонового потока на выполнение
            backgroundWorker1.RunWorkerAsync();

        }

        /* Получение активных 
         * логических дисков
         */
        private void getDrives()
        {
            List<string> temp = new List<string>();

            //Получение всех дисков
            DriveInfo[] driveInfo = DriveInfo.GetDrives();
            //Выделение активных дисков
            foreach (DriveInfo drive in driveInfo)
                if (drive.DriveType == DriveType.Fixed || (drive.DriveType == DriveType.Removable && drive.IsReady))
                    temp.Add(drive.Name);

            //Инициализация массива с активными дисками
            dirInDirectory = new string[temp.Count];

            //Добавление в массив активных дисков
            for (int i = 0; i < dirInDirectory.Length; i++)
                dirInDirectory[i] = temp[i];
        }

        /* Поиск дублей в случае,
         * если указан конкретный файл, 
         * основная функция
         */
        private void getDoubles(string[] files, string[] folders, string needFile)
        {
            /* Если в директории отсутствуют папки,
             * проверяются файлы на схожесть с дублем, 
             * если они есть
             */
            if (folders.Length == 0)
            {
                if (files.Length != 0)
                    foreach (string file in files)
                    {
                        string fileName = getFileName(file);
                        if (fileName.Equals(needFile))
                            needFiles.Add(file);
                        countOfFile++;
                        backgroundWorker1.ReportProgress(countOfFile);
                    }
            }
            else
            {
                /* Если же папки есть, 
                 * то проверка осуществляется и в них   
                 */
                if (files.Length != 0)
                    foreach (string file in files)
                    {
                        string fileName = getFileName(file);
                        if (fileName.Equals(needFile))
                            needFiles.Add(file);
                        countOfFile++;
                        backgroundWorker1.ReportProgress(countOfFile);
                    }

                if (folders.Length != 0)
                    foreach (string folder in folders)
                    {
                        string[] nFiles = new string[0], nFolders = new string[0];
                        try
                        {
                            nFiles = Directory.GetFiles(folder);
                            nFolders = Directory.GetDirectories(folder);
                        }
                        catch (UnauthorizedAccessException e)
                        {
                            Console.Out.WriteLine(e.Message);
                        }
                        getDoubles(nFiles, nFolders, needFile);
                    }

            }
        }

        /* Поиск дублей,
         * если конкретный файл не указан, 
         * основная функция
         */
        private void getDoubles(string[] files, string[] folders)
        {
            if (folders.Length == 0)
            {
                if (files.Length != 0)
                    foreach (string file in files)
                    {
                        string fileCont = "";

                        bool contains = false;

                        foreach (string alFile in allFiles)
                            if (getFileName(alFile).Equals(getFileName(file)))
                            {
                                contains = true;
                                fileCont = alFile;
                                break;
                            }

                        if (!contains)
                            allFiles.Add(file);
                        else
                        {
                            needFiles.Add(file);

                            bool cont = false;

                            foreach (string dFile in needFiles)
                                if (dFile.Equals(fileCont))
                                {
                                    cont = true;
                                    allFiles.Remove(fileCont);
                                    break;
                                }

                            if (!cont)
                                needFiles.Add(fileCont);
                        }
                        countOfFile++;
                        backgroundWorker1.ReportProgress(countOfFile);

                    }
            }
            else
            {
                if (files.Length != 0)
                    foreach (string file in files)
                    {
                        string fileCont = "";

                        bool contains = false;

                        foreach (string alFile in allFiles)
                            if (getFileName(alFile).Equals(getFileName(file)))
                            {
                                contains = true;
                                fileCont = alFile;
                                break;
                            }

                        if (!contains)
                            allFiles.Add(file);
                        else
                        {
                            needFiles.Add(file);

                            bool cont = false;

                            foreach (string dFile in needFiles)
                                if (dFile.Equals(fileCont))
                                {
                                    cont = true;
                                    allFiles.Remove(fileCont);
                                    break;
                                }

                            if (!cont)
                                needFiles.Add(fileCont);
                        }
                        countOfFile++;
                        backgroundWorker1.ReportProgress(countOfFile);

                    }

                if (folders.Length != 0)
                    foreach (string folder in folders)
                    {
                        string[] nFiles = new string[0], nFolders = new string[0];
                        try
                        {
                            nFiles = Directory.GetFiles(folder);
                            nFolders = Directory.GetDirectories(folder);
                        }
                        catch (UnauthorizedAccessException e)
                        {
                            Console.Out.WriteLine(e.Message);
                        }
                        getDoubles(nFiles, nFolders);
                    }

            }
        }

        /*
         *  Получение имени файла из пути полного пути 
         */
        private string getFileName(string fullPath)
        {
            int slash = 0;
            int point = -1;

            for (int i = fullPath.Length - 1; i >= 0; i--)
            {
                if (fullPath[i] == '.' && point == -1)
                    point = i;

                if (fullPath[i] == '\\')
                {
                    slash = i + 1;
                    break;
                }

            }
            if (point == -1)
                return fullPath.Substring(slash, fullPath.Length - slash);

            return fullPath.Substring(slash, point - slash);
        }

        /* Получение кол-ва всех файлов, 
         * которые будут просмотрены
         */
        public void getFilesCount(string[] files, string[] folders)
        {
            if (folders.Length == 0)
            {
                if (files.Length != 0)
                    foreach (string file in files)
                        countOfFile++;
            }
            else
            {
                if (files.Length != 0)
                    foreach (string file in files)
                        countOfFile++;

                if (folders.Length != 0)
                    foreach (string folder in folders)
                    {
                        string[] nFiles = new string[0], nFolders = new string[0];
                        try
                        {
                            nFiles = Directory.GetFiles(folder);
                            nFolders = Directory.GetDirectories(folder);
                        }
                        catch (UnauthorizedAccessException e)
                        {
                            Console.Out.WriteLine(e.Message);
                        }
                        getFilesCount(nFiles, nFolders);
                    }

            }
        }

        // Ставит галочку на все файлы
        private void button1_Click_1(object sender, EventArgs e)
        {
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
                checkedListBox1.SetItemChecked(i, true);
        }

        // Снимает галочку со всех файлов
        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
                checkedListBox1.SetItemChecked(i, false);
        }

        private void setMaxValue()
        {
            progressBar1.Value = 0;
            progressBar1.Maximum = countOfFile;
        }

        private void backgroundWorker1_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {

            countOfFile = 0;
            getFilesCount(filesInDirectory, dirInDirectory);

            if (!progressBar1.InvokeRequired)
            {
                progressBar1.Value = 0;
                progressBar1.Maximum = countOfFile;
            }
            else
            {
                SetPBMaxValue del = new SetPBMaxValue(setMaxValue);
                progressBar1.Invoke(del);
            }

            countOfFile = 0;
            if (doubleName.Text.Equals("*"))
                getDoubles(filesInDirectory, dirInDirectory);
            else
                getDoubles(filesInDirectory, dirInDirectory, doubleFileName);

        }



        private void backgroundWorker1_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            foreach (string needFile in needFiles)
                checkedListBox1.Items.Add(needFile);
            panel1.Enabled = true;
            allFiles.Clear();
            needFiles.Clear();
        }

        private void checkedListBox1_ItemCheck(object sender, ItemCheckEventArgs e)
        {
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string action = FileAction.GetItemText(FileAction.SelectedItem);
            if (action.Equals("Удалить"))
            {
                try
                {
                    for (int i = 0; i < checkedListBox1.Items.Count; i++)
                        if (checkedListBox1.GetItemChecked(i))
                        {
                            string currentCheckedFile = checkedListBox1.Items[i].ToString();
                            if (File.Exists(currentCheckedFile))
                                File.Delete(currentCheckedFile);
                            checkedListBox1.Items.RemoveAt(i);
                        }
                    MessageBox.Show("Удаление файла(-ов) прошло успешно!");
                }
                catch(IOException exp)
                {
                    MessageBox.Show(exp.Message + "\r\nУдаление файла(-ов) прервано!");
                }
                
            }
            else if (action.Equals("Переместить"))
            {
                try
                {
                    for (int i = 0; i < checkedListBox1.Items.Count; i++)
                        if (checkedListBox1.GetItemChecked(i))
                        {
                            string currentCheckedFile = checkedListBox1.Items[i].ToString();
                            if (File.Exists(currentCheckedFile))
                                File.Move(currentCheckedFile, Path.Combine(endPath.Text, getFileNameWithExt(currentCheckedFile)));
                            checkedListBox1.Items.RemoveAt(i);
                        }
                    MessageBox.Show("Перемещение файла(-ов) прошло успешно!");

                }
                catch(IOException exp)
                {
                    MessageBox.Show(exp.Message+"\r\nПеремещение файла(-ов) прервано!");
                }
            }
            else if(action.Equals("Копировать"))
            {
                try
                {
                    for (int i = 0; i < checkedListBox1.Items.Count; i++)
                        if (checkedListBox1.GetItemChecked(i))
                        {
                            string currentCheckedFile = checkedListBox1.Items[i].ToString();
                            if (File.Exists(currentCheckedFile))
                                File.Copy(currentCheckedFile, Path.Combine(endPath.Text, getFileNameWithExt(currentCheckedFile))); ;
                        }
                    MessageBox.Show("Копирование файла(-ов) прошло успешно!");
                }
                catch(IOException exp)
                {
                    MessageBox.Show(exp.Message+"\r\nКопирование файла(-ов) прервано!");
                }
                
                
            }
               

        }

        private string getFileNameWithExt(string fullPath)
        {
            int slash = 0;

            for (int i = fullPath.Length - 1; i >= 0; i--)
            {

                if (fullPath[i] == '\\')
                {
                    slash = i + 1;
                    break;
                }

            }

            return fullPath.Substring(slash);
        }

        private void backgroundWorker1_ProgressChanged(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            progressBar1.Value = e.ProgressPercentage;
        }

        private void FileAction_DropDownClosed(object sender, EventArgs e)
        {
            string action = FileAction.GetItemText(FileAction.SelectedItem);

            if (action.Equals("Переместить") || action.Equals("Копировать") || action.Equals("Вырезать"))
                panel3.Visible = true;
            else if(action.Equals("Удалить"))
                panel3.Visible = false;

            isChooseItem();
            
        }

        private void isChooseItem()
        {
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
                if (checkedListBox1.GetSelected(i))
                {
                    button4.Enabled = true;
                    return;
                }
            button4.Enabled = false;
        }

        private void EndFolder_Click(object sender, EventArgs e)
        {
            if (FolderDialog.ShowDialog() == DialogResult.OK)
                endPath.Text = FolderDialog.SelectedPath;
        }

        private void endPath_TextChanged(object sender, EventArgs e)
        {
            if (endPath.Text.Equals("") || !Directory.Exists(endPath.Text) || endPath.Text.Equals(path.Text))
                button4.Enabled = false;
            else
                button4.Enabled = true;
            isChooseItem();
        }
        
        private void doubleName_TextChanged(object sender, EventArgs e)
        {
            string doubleFileName = doubleName.Text;
            string filePath = path.Text;
            
            if (doubleFileName.Equals("") || filePath.Equals(""))
                searchButton.Enabled = false;
            else if (!doubleFileName.Equals("") && !filePath.Equals("") && (Directory.Exists(filePath) || filePath.Equals("*")))
                searchButton.Enabled = true;
        }
    }
}
